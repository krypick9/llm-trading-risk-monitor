# Crypto Risk Monitor: results for BTCUSDT

Training days: 2025-09-24 to 2025-10-09 (16 days)  
Test days: 2025-10-10 to 2025-10-13 (4 days, never seen in training)  
Label horizon: next 15 minutes. Levels from training percentiles 90 / 97 / 99.5.

## Test-period performance

| Dimension | Model | Macro F1 | Critical recall | Critical precision | PR-AUC (Warning+) | Base rate (Warning+) | Brier |
|---|---|---|---|---|---|---|---|
| sync | naive | 0.2655 | 0.0 | 0.0 | 0.0077 | 0.0077 | 0.0153 |
| sync | logit | 0.2483 | 0.0 | 0.0 | 0.0092 | 0.0077 | 0.0895 |
| sync | gboost | 0.2729 | 0.0 | 0.0 | 0.0147 | 0.0077 | 0.0226 |
| sync | hybrid | 0.2685 | 0.0 | 0.0 | 0.0133 | 0.0077 | 0.0302 |
| liquidity | naive | 0.423 | 0.3974 | 0.4138 | 0.2399 | 0.1076 | 0.1239 |
| liquidity | logit | 0.1995 | 0.298 | 0.0646 | 0.2349 | 0.1076 | 0.3035 |
| liquidity | gboost | 0.2452 | 0.0 | 0.0 | 0.0906 | 0.1076 | 0.1173 |
| liquidity | hybrid | 0.3814 | 0.3974 | 0.3109 | 0.2887 | 0.1076 | 0.1328 |
| instability | naive | 0.4997 | 0.5231 | 0.5231 | 0.4457 | 0.2279 | 0.1849 |
| instability | logit | 0.2938 | 0.0648 | 0.0996 | 0.5891 | 0.2279 | 0.238 |
| instability | gboost | 0.3316 | 0.0185 | 0.2667 | 0.4852 | 0.2279 | 0.1637 |
| instability | hybrid | 0.4559 | 0.5231 | 0.5136 | 0.5138 | 0.2279 | 0.1975 |

PR-AUC should be compared with the base rate: a model with no skill scores roughly the base rate.
naive = assume the next 15 minutes look like the last 15. hybrid = higher of gboost and naive (the tool's main output).

## Crash lead time (instability, hybrid detector)

- event onset (UTC): 2025-10-10 19:30:00
- price at onset: 116,359
- price low in window: 101,516 at 2025-10-10 21:20:00
- alarm switched on (UTC): 2025-10-10 19:11:00
- warning lead time: 19 minutes
- first minute with P(Warning+) >= 0.5 in window: 2025-10-10 19:11:00

## Alarm episodes per test day (P(instability Warning+) >= 0.5)

- 2025-10-10: 6
- 2025-10-11: 32
- 2025-10-12: 24
- 2025-10-13: 23

## Top early-warning features (permutation importance)

- **sync**: range_15, rv_15, log_tob_depth, spread_ratio_60, spread_bps
- **liquidity**: log_rv_60, range_15, spread_bps, rv_ratio_15_60, log_near_depth
- **instability**: log_rv_60, rv_15, range_15, near_depth_ratio_60, abs_ret_1

## Thresholds learned from training scores

```
{
  "sync": [
    0.30572699219438715,
    0.3969862566953709,
    0.5132395892052111
  ],
  "liquidity": [
    1.9085251011708229,
    2.376711940149751,
    2.820320246476581
  ],
  "instability": [
    0.0005965564039294111,
    0.0008303876039754532,
    0.0012596537279577634
  ]
}
```
