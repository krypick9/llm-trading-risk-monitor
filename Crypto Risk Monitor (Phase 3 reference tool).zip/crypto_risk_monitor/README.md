# Crypto Risk Monitor — a reference tool for Phase 3

A small, working version of our Phase 3 detector, built entirely on **free public crypto data**. It downloads real BTCUSDT perpetual-futures data, builds the group A features, labels market risk, trains two models per risk dimension, and tests them on the 10 October 2025 crash, which the models never see during training.

## Data sources

| Source | File used | Features built from it |
|---|---|---|
| **Binance USD-M futures, `aggTrades`** ([data.binance.vision](https://data.binance.vision/?prefix=data/futures/um/daily/aggTrades/)) | Daily trade-by-trade archive. The `is_buyer_maker` flag tells us whether each trade was buyer- or seller-initiated. | Returns, rolling volatility, volatility acceleration, price range, volume, buy/sell imbalance, same-direction persistence |
| **Bybit linear perpetual order book** ([format notes](https://github.com/Anton495/bybit-data-downloader)) | Daily order-book file, 200 levels (500 for older dates), as a snapshot followed by changes ~10 times a second | Spread, spread widening, top-of-book depth, depth within 0.1% of mid, depth decline speed, top-of-book imbalance |

Both files are free and need no account. Each day, the Bybit file (~300 MB) is turned into 1-second top-of-book values, aggregated to 1-minute bars, and then deleted. Only the small minute-bar files are kept in `cache/`.

## How it maps to Phase 3

| Phase 3 component | In this tool |
|---|---|
| Inputs sₜ (observable only) | 18 features on 1-minute bars, using only past and current data (`crm/features.py`) |
| Risk levels per dimension | Three dimensions, each Normal / Watch / Warning / Critical (`crm/labels.py`) |
| Models | Naive baseline, logistic regression, gradient boosting, and a **hybrid** (higher of gradient boosting and naive), one per dimension (`crm/model.py`, `crm/__main__.py`) |
| Time-series features | Rolling 15- and 60-minute windows: levels, changes, ratios to recent median |
| Escalation forecast | P(Warning or worse) over the next 15 minutes |
| Early-warning indicators | Permutation importance per dimension |
| External validation | Train on 24 Sep – 9 Oct 2025, test on 10–13 Oct 2025 |

### How the labels work

In the simulation, the risk label Rₜ comes from hidden variables such as agent correlation. Real data has no hidden truth, so this tool scores each dimension by **what actually happens over the next 15 minutes**:

- **Synchronisation:** how one-sided the next 15 minutes of trading are, measured as |net signed volume| ÷ total volume.
- **Liquidity fragility:** the worst depth loss (or spread blow-out) in the next 15 minutes, compared with the previous 24 hours.
- **Market instability:** realised volatility over the next 15 minutes.

Levels are cut at the 90th, 97th and 99.5th percentiles of the **training** period. "Critical" therefore means rarer than 1 minute in 200 under normal conditions.

So the model is an early-warning detector: at time t, it only sees the past and predicts the risk level for the next 15 minutes. When the simulation is ready, its labelled (sₜ, Rₜ) pairs can be added to the same training table.

## How to run

```bash
pip install pandas numpy requests scikit-learn matplotlib pyarrow joblib orjson
cd crypto_risk_monitor

# Train + test (first run downloads ~20 days; about 12 minutes, then cached)
python -m crm train --symbol BTCUSDT --train 2025-09-24:2025-10-09 --test 2025-10-10:2025-10-13

# Apply the trained detector to any new day
python -m crm score --symbol BTCUSDT --day 2025-10-20
```

Outputs in `output/`:
- `report.md`: metrics, lead time, alarms per day, top features.
- `crash_window.png`: price, flow, spread, depth, detector output vs what happened.
- `escalation_probability.png`: P(Warning or worse) per dimension.
- `feature_importance.png`: early-warning indicators.
- `test_predictions.csv`, `dataset_minutes.csv`: the full minute-level tables, for your own analysis.
- `detector.joblib`: the trained models and thresholds.

## Results on the 10–13 October 2025 test period

Train: 24 Sep – 9 Oct 2025 (16 days). Test: 10–13 Oct 2025 (4 days, never seen in training). "Naive" means assuming the next 15 minutes look like the last 15.

| Dimension | Model | Macro F1 | Critical recall | PR-AUC (Warning+) | Base rate |
|---|---|---|---|---|---|
| Instability | naive | 0.50 | 0.52 | 0.45 | 0.23 |
| Instability | logit | 0.29 | 0.06 | **0.59** | 0.23 |
| Instability | gboost | 0.33 | 0.02 | 0.49 | 0.23 |
| Instability | **hybrid** | 0.46 | 0.52 | 0.51 | 0.23 |
| Liquidity | naive | **0.42** | 0.40 | 0.24 | 0.11 |
| Liquidity | logit | 0.20 | 0.30 | 0.23 | 0.11 |
| Liquidity | gboost | 0.25 | 0.00 | 0.09 | 0.11 |
| Liquidity | **hybrid** | 0.38 | 0.40 | **0.29** | 0.11 |
| Sync | all models | about 0.27 | 0.00 | 0.01 | 0.008 |

What this tells us:

1. **The naive baseline is hard to beat.** Risk is persistent: a volatile 15 minutes is usually followed by another. Any Phase 3 model has to be compared against this, not just against random guessing.
2. **Gradient boosting cannot go beyond what it has seen.** Trained on calm September days, it almost never predicts Critical during the crash; it stops at Warning. Tree models cannot extrapolate. Logistic regression extrapolates and has the best ranking skill for instability (PR-AUC 0.59 vs base rate 0.23), but its levels are poorly calibrated.
3. **The hybrid is the practical choice.** Taking the higher of the model and the naive level keeps the naive Critical recall and improves liquidity ranking (PR-AUC 0.29 vs 0.24).
4. **The main crash itself was not predicted early.** The alarm switched on at 19:11 UTC for an earlier volatile spell, then switched off between about 20:10 and 20:50. It came back on as the main sell-off started around 20:50. So the warning came with the drop, not before it.
5. **Too many false alarms on calm days.** On 20 October (`score` command), the hybrid flagged Warning or worse for 42% of minutes on instability, while only 8% actually reached that level. The balanced class weights push the model to over-alarm. The alarm threshold should be tuned on a separate validation period.
6. **Synchronisation, measured as one-sided flow on Binance, did not spike in this crash.** Flow over 15-minute windows stayed mixed. A better sync measure on real data could use liquidation volume or cross-venue flow.

Lessons for Phase 3: train on several stress episodes, not just calm days (this is exactly where simulation data helps); always report the naive baseline; tune alarm thresholds on a separate validation period; and add leverage features (open interest, liquidations).

## Files

```
crm/
  bybit_book.py   rebuild the Bybit order book, sample top of book every second
  data.py         download + cache Binance trades and Bybit book, one day at a time
  features.py     group A features (past data only)
  labels.py       forward-looking risk scores and percentile levels
  model.py        logistic regression vs gradient boosting, evaluation, importance
  report.py       charts and markdown report
  __main__.py     command line: train / score
```

## Known limits (worth saying out loud)

- **Two venues.** Trades come from Binance and the order book from Bybit. Both are BTCUSDT perpetuals and move together closely, but a single-venue version would use Bybit trades as well (`public.bybit.com/trading/`).
- **Tick-bound spread.** BTC's spread is usually one tick (about 0.01 bps), so spread only carries information in stress. Depth is the more informative liquidity signal.
- **Calm training data.** All 16 training days are relatively calm, so the models have seen very few Critical minutes. This is the main reason gradient boosting underestimates severity.
- **One big event.** The test period has one major crash. More events, other coins (ETHUSDT, SOLUSDT) and calmer weeks are needed before claiming the detector generalises.
- **Labels are a design choice.** The percentiles and the 15-minute horizon are starting points, to be replaced by Phase 1 change-point thresholds later.
- **Data quality.** Always check coverage (`book_secs` column = seconds per minute with a valid book). Binance's own `bookDepth` file froze on the bid side during this crash, which is why this tool uses the Bybit book.
