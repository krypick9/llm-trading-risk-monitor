"""Crypto Risk Monitor: a small reference implementation of Phase 3.

Binance USD-M aggTrades  -> returns, volatility, volume, buy/sell imbalance, persistence
Bybit linear order book  -> spread, top-of-book depth, near-touch depth
"""
