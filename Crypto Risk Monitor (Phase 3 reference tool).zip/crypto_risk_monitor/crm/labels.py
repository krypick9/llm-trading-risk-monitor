"""Outcome-based risk labels for real data.

Real markets have no simulator telling us the 'true' risk, so each dimension is
scored by what happens over the NEXT `H` minutes. Levels are set from percentiles
of the training period, so 'Critical' means rarer than 1 minute in 200 in training.
"""
import numpy as np
import pandas as pd

LEVELS = ["Normal", "Watch", "Warning", "Critical"]
PCTS = (0.90, 0.97, 0.995)
DIMS = ["sync", "liquidity", "instability"]


def _fwd(s, h, how):
    # value over t+1 ... t+h, aligned to t
    r = getattr(s[::-1].rolling(h, min_periods=h), how)()[::-1]
    return r.shift(-1)


def risk_scores(df, h=15):
    """Continuous forward risk score per dimension (higher = worse)."""
    out = pd.DataFrame(index=df.index)
    # 1) Synchronisation: how one-sided the next h minutes of flow are
    out["sync"] = (_fwd(df.signed_usd, h, "sum") / _fwd(df.vol_usd, h, "sum")).abs()
    # 2) Liquidity fragility: worst depth loss or spread blow-out vs the trailing day
    base_depth = df.near_depth_usd.rolling(1440, min_periods=360).median()
    base_spread = df.spread_bps_mean.rolling(1440, min_periods=360).median()
    depth_loss = -np.log(_fwd(df.near_depth_min_usd, h, "min") / base_depth)
    spread_blow = np.log(_fwd(df.spread_bps_max, h, "max") / base_spread)
    out["liquidity"] = np.fmax(depth_loss, spread_blow / 2.0)  # spread is tick-bound, so halve its weight
    # 3) Market instability: realised volatility over the next h minutes
    lr = np.log(df.close).diff()
    out["instability"] = _fwd(lr, h, "std")
    return out


def fit_thresholds(scores):
    return {d: scores[d].quantile(list(PCTS)).values.tolist() for d in DIMS}


def to_levels(scores, thr):
    lv = pd.DataFrame(index=scores.index)
    for d in DIMS:
        lv[d] = np.digitize(scores[d], thr[d])  # 0..3
        lv.loc[scores[d].isna(), d] = -1
    return lv.astype(int)


def _back(s, h, how):
    # value over t-h+1 ... t (what has already happened)
    return getattr(s.rolling(h, min_periods=h), how)()


def naive_levels(df, h, thr):
    """Naive benchmark: assume the next h minutes look like the last h minutes."""
    out = pd.DataFrame(index=df.index)
    out["sync"] = (_back(df.signed_usd, h, "sum") / _back(df.vol_usd, h, "sum")).abs()
    base_depth = df.near_depth_usd.rolling(1440, min_periods=360).median()
    base_spread = df.spread_bps_mean.rolling(1440, min_periods=360).median()
    depth_loss = -np.log(_back(df.near_depth_min_usd, h, "min") / base_depth)
    spread_blow = np.log(_back(df.spread_bps_max, h, "max") / base_spread)
    out["liquidity"] = np.fmax(depth_loss, spread_blow / 2.0)
    out["instability"] = _back(np.log(df.close).diff(), h, "std")
    return to_levels(out, thr)
