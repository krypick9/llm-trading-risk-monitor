"""Download and cache the two free data sources, one day at a time."""
import io, os, zipfile, time
import numpy as np
import pandas as pd
import requests
from .bybit_book import URL as BYBIT_URL, parse_orderbook_zip, book_to_minutes

BINANCE_URL = "https://data.binance.vision/data/futures/um/daily/aggTrades/{sym}/{sym}-aggTrades-{day}.zip"
CACHE = os.environ.get("CRM_CACHE", os.path.join(os.path.dirname(__file__), "..", "cache"))


def _get(url, path=None, tries=3):
    for i in range(tries):
        try:
            r = requests.get(url, timeout=600, stream=path is not None)
            r.raise_for_status()
            if path is None:
                return r.content
            with open(path, "wb") as f:
                for chunk in r.iter_content(1 << 20):
                    f.write(chunk)
            return path
        except Exception as e:  # network hiccup
            if i == tries - 1:
                raise RuntimeError(f"download failed: {url} ({e})")
            time.sleep(3)


def binance_minutes(sym, day):
    """1-minute bars from Binance aggTrades (buyer-maker = seller-initiated)."""
    out = os.path.join(CACHE, f"binance_{sym}_{day}.parquet")
    if os.path.exists(out):
        return pd.read_parquet(out)
    os.makedirs(CACHE, exist_ok=True)
    z = zipfile.ZipFile(io.BytesIO(_get(BINANCE_URL.format(sym=sym, day=day))))
    t = pd.read_csv(z.open(z.namelist()[0]))
    if "transact_time" not in t.columns:  # some older files have no header
        t.columns = ["agg_trade_id", "price", "quantity", "first_trade_id", "last_trade_id",
                     "transact_time", "is_buyer_maker"][: len(t.columns)]
    t["ts"] = pd.to_datetime(t.transact_time, unit="ms")
    sell = t.is_buyer_maker.astype(str).str.lower().eq("true")
    t["usd"] = t.price * t.quantity
    t["signed_usd"] = np.where(sell, -1.0, 1.0) * t.usd
    g = t.set_index("ts").resample("1min")
    bars = pd.DataFrame({
        "open": g.price.first(), "high": g.price.max(), "low": g.price.min(), "close": g.price.last(),
        "vol_usd": g.usd.sum(), "signed_usd": g.signed_usd.sum(), "n_trades": g.price.count(),
    })
    bars.to_parquet(out)
    return bars


def bybit_minutes(sym, day, levels=200):
    """1-minute top-of-book bars rebuilt from the Bybit daily order-book file."""
    out = os.path.join(CACHE, f"bybit_{sym}_{day}.parquet")
    if os.path.exists(out):
        return pd.read_parquet(out)
    os.makedirs(CACHE, exist_ok=True)
    tmp = os.path.join(CACHE, f"_tmp_{sym}_{day}.zip")
    last_err = None
    for lvl in (levels, 500, 200):  # older dates use 500-level files
        try:
            _get(BYBIT_URL.format(sym=sym, day=day, lvl=lvl), tmp)
            break
        except RuntimeError as e:
            last_err = e
    else:
        raise last_err
    try:
        bars = book_to_minutes(parse_orderbook_zip(tmp))
    finally:
        os.remove(tmp)  # raw file is ~300 MB; keep only the minute bars
    bars.to_parquet(out)
    return bars


def load_days(sym, days, verbose=True):
    frames = []
    for d in days:
        t0 = time.time()
        b = binance_minutes(sym, d)
        k = bybit_minutes(sym, d)
        frames.append(b.join(k, how="left"))
        if verbose:
            print(f"  {d}: {len(b)} minutes  ({time.time() - t0:.0f}s)", flush=True)
    return pd.concat(frames).sort_index()
