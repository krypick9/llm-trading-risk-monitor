"""Charts and a markdown report."""
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import ListedColormap, BoundaryNorm
from .labels import DIMS, LEVELS

LEVEL_COLORS = ["#E8E6E1", "#7FA7C9", "#E0A030", "#B8323F"]  # Normal, Watch, Warning, Critical
CMAP = ListedColormap(LEVEL_COLORS)
NORM = BoundaryNorm([-0.5, 0.5, 1.5, 2.5, 3.5], 4)
INK, MUTED, ACCENT = "#28251D", "#7A7974", "#1F6F6B"
NAMES = {"sync": "Synchronisation", "liquidity": "Liquidity fragility", "instability": "Market instability"}

plt.rcParams.update({"font.size": 9, "axes.edgecolor": "#BAB9B4", "axes.labelcolor": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False,
                     "axes.spines.right": False})


def _heat(ax, frame, title):
    arr = np.vstack([frame[d].values for d in DIMS]).astype(float)
    arr[arr < 0] = np.nan
    x = mdates.date2num(frame.index.to_pydatetime())
    ax.pcolormesh(np.append(x, x[-1] + (x[1] - x[0])), np.arange(4), arr, cmap=CMAP, norm=NORM, shading="flat")
    ax.set_yticks([0.5, 1.5, 2.5], [NAMES[d] for d in DIMS])
    ax.set_title(title, loc="left", fontsize=9, color=INK)
    ax.invert_yaxis()


def crash_chart(df, feats, actual, pred, pwarn, start, end, path, model_name):
    w = slice(start, end)
    fig, axes = plt.subplots(6, 1, figsize=(11, 12), sharex=True,
                             gridspec_kw={"height_ratios": [1.3, 1, 1, 1, 0.8, 0.8]})
    ax = axes[0]
    ax.plot(df.close[w], color=INK, lw=1.1)
    ax.set_ylabel("BTCUSDT price (USD)")
    ax.set_title(f"BTCUSDT perpetual, {start[:10]} crash window (UTC)", loc="left", fontsize=11, color=INK)
    ax = axes[1]
    ax.axhline(0, color="#BAB9B4", lw=0.8)
    ax.plot(feats.ofi_15[w], color=ACCENT, lw=1, label="15-min buy/sell imbalance")
    ax.plot(feats.persist_signed_15[w], color="#A84B2F", lw=1, alpha=0.8, label="15-min same-direction persistence (signed)")
    ax.set_ylim(-1.05, 1.05); ax.legend(loc="lower left", fontsize=8, frameon=False)
    ax.set_ylabel("Binance flow")
    ax = axes[2]
    ax.semilogy(feats.spread_bps[w], color="#A84B2F", lw=1)
    ax.set_ylabel("Bybit spread (bps, log)")
    ax = axes[3]
    ax.semilogy(df.near_depth_usd[w], color=ACCENT, lw=1, label="Depth within 0.1% of mid")
    ax.semilogy(df.tob_depth_usd[w], color=MUTED, lw=1, label="Best bid + ask size")
    ax.set_ylabel("Bybit depth (USD, log)"); ax.legend(loc="lower left", fontsize=8, frameon=False)
    _heat(axes[4], pred[w], f"Detector output ({model_name}): predicted level for the next 15 minutes")
    _heat(axes[5], actual[w], "What actually happened: realised level over the next 15 minutes")
    axes[5].xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in LEVEL_COLORS]
    fig.legend(handles, LEVELS, loc="lower center", ncol=4, frameon=False, fontsize=9)
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(path, dpi=150); plt.close(fig)


def prob_chart(pwarn_by_dim, start, end, path):
    fig, ax = plt.subplots(figsize=(11, 3.4))
    colors = {"sync": "#7FA7C9", "liquidity": ACCENT, "instability": "#B8323F"}
    for d in DIMS:
        ax.plot(pwarn_by_dim[d][start:end], color=colors[d], lw=1.1, label=NAMES[d])
    ax.axhline(0.5, color=MUTED, ls="--", lw=0.8)
    ax.set_ylim(0, 1); ax.set_ylabel("P(Warning or worse)")
    ax.set_title("Escalation probability for the next 15 minutes (hybrid detector)", loc="left", fontsize=10, color=INK)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=3, fontsize=8, frameon=False)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def importance_chart(importance, path):
    fig, axes = plt.subplots(1, 3, figsize=(12, 4.2))
    for ax, d in zip(axes, DIMS):
        s = importance[d].head(8)[::-1]
        ax.barh(s.index, s.values, color=ACCENT)
        ax.set_title(NAMES[d], loc="left", fontsize=10, color=INK)
        ax.set_xlabel("Drop in macro F1 when shuffled")
    fig.suptitle("Early-warning indicators: most important features per dimension (test period)",
                 x=0.01, ha="left", fontsize=11, color=INK)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def write_report(path, cfg, results, lead, alarms, importance, thresholds):
    L = [f"# Crypto Risk Monitor: results for {cfg['symbol']}", "",
         f"Training days: {cfg['train'][0]} to {cfg['train'][-1]} ({len(cfg['train'])} days)  ",
         f"Test days: {cfg['test'][0]} to {cfg['test'][-1]} ({len(cfg['test'])} days, never seen in training)  ",
         f"Label horizon: next {cfg['horizon']} minutes. Levels from training percentiles 90 / 97 / 99.5.", "",
         "## Test-period performance", "",
         "| Dimension | Model | Macro F1 | Critical recall | Critical precision | PR-AUC (Warning+) | Base rate (Warning+) | Brier |",
         "|---|---|---|---|---|---|---|---|"]
    for (d, m), r in results.items():
        L.append(f"| {d} | {m} | {r['macro_f1']} | {r['critical_recall']} | {r['critical_precision']} | "
                 f"{r['warning_plus_pr_auc']} | {r['warning_plus_base_rate']} | {r['warning_plus_brier']} |")
    L += ["", "PR-AUC should be compared with the base rate: a model with no skill scores roughly the base rate.",
          "naive = assume the next 15 minutes look like the last 15. hybrid = higher of gboost and naive (the tool's main output).", "",
          "## Crash lead time (instability, hybrid detector)", ""]
    L += [f"- {k}: {v}" for k, v in lead.items()]
    L += ["", "## Alarm episodes per test day (P(instability Warning+) >= 0.5)", ""]
    L += [f"- {k}: {v}" for k, v in alarms.items()]
    L += ["", "## Top early-warning features (permutation importance)", ""]
    for d in DIMS:
        L.append(f"- **{d}**: " + ", ".join(importance[d].head(5).index))
    L += ["", "## Thresholds learned from training scores", "", "```", json.dumps(thresholds, indent=2), "```"]
    open(path, "w").write("\n".join(L) + "\n")
