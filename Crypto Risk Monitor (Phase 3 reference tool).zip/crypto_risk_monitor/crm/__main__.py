"""Command-line entry point.

  python -m crm train --symbol BTCUSDT --train 2025-09-24:2025-10-09 --test 2025-10-10:2025-10-13
  python -m crm score --symbol BTCUSDT --day 2025-10-20
"""
import argparse, json, os
import joblib
import numpy as np
import pandas as pd
from .data import load_days
from .features import FEATURES, build_features
from .labels import DIMS, fit_thresholds, naive_levels, risk_scores, to_levels
from .model import evaluate, prob_warning_plus, train_all
from . import report

OUT = os.path.join(os.path.dirname(__file__), "..", "output")


def _days(rng):
    a, b = rng.split(":")
    return [d.strftime("%Y-%m-%d") for d in pd.date_range(a, b, freq="D")]


def _alarm_episodes(p, thr=0.5, min_len=3, gap=5):
    """Contiguous minutes with p >= thr (gaps of up to `gap` minutes are bridged)."""
    idx = np.flatnonzero((p >= thr).values)
    if len(idx) == 0:
        return []
    eps, start, prev = [], idx[0], idx[0]
    for k in idx[1:]:
        if k - prev > gap:
            eps.append((start, prev))
            start = k
        prev = k
    eps.append((start, prev))
    return [(p.index[a], p.index[b]) for a, b in eps if b - a + 1 >= min_len]


def cmd_train(a):
    os.makedirs(OUT, exist_ok=True)
    tr, te = _days(a.train), _days(a.test)
    print("Loading data ...", flush=True)
    df = load_days(a.symbol, tr + te)
    feats = build_features(df)
    scores = risk_scores(df, a.horizon)
    is_tr = df.index < pd.Timestamp(te[0])
    tr_idx = df.index[is_tr][:-a.horizon]           # purge: last labels look into the test period
    te_idx = df.index[~is_tr]
    thr = fit_thresholds(scores.loc[tr_idx])
    levels = to_levels(scores, thr)
    print("Training models ...", flush=True)
    results, preds, fitted, imp = train_all(feats.loc[tr_idx], levels.loc[tr_idx],
                                            feats.loc[te_idx], levels.loc[te_idx], FEATURES)
    naive = naive_levels(df, a.horizon, thr)
    for d in DIMS:
        y = levels.loc[te_idx, d]; mk = (y >= 0) & (naive.loc[te_idx, d] >= 0)
        pn = naive.loc[te_idx, d][mk]
        results[(d, "naive")] = evaluate(y[mk].values, pn.values, (pn >= 2).astype(float).values)
    results = dict(sorted(results.items(), key=lambda kv: (DIMS.index(kv[0][0]), ["naive", "logit", "gboost"].index(kv[0][1]))))
    for (d, m), r in results.items():
        print(f"  {d:12s} {m:7s} {r}")

    # Hybrid detector: higher of (gradient boosting forecast, naive "last 15 minutes" level).
    # Trees cannot extrapolate beyond calm training data; the naive rule covers that gap.
    best = "hybrid"
    pred, pwarn = pd.DataFrame(index=te_idx), {}
    for d in DIMS:
        gb_pred, gb_p = preds[(d, "gboost")]
        nv = naive.loc[te_idx, d]
        pred[d] = np.maximum(gb_pred, nv)
        pwarn[d] = pd.Series(np.maximum(gb_p, (nv >= 2).astype(float)), index=te_idx)
        y = levels.loc[te_idx, d]; mk = (y >= 0) & (nv >= 0)
        results[(d, "hybrid")] = evaluate(y[mk].values, pred[d][mk].values, pwarn[d][mk].values)
    results = dict(sorted(results.items(), key=lambda kv: (DIMS.index(kv[0][0]), ["naive", "logit", "gboost", "hybrid"].index(kv[0][1]))))
    for d in DIMS:
        print(f"  {d:12s} hybrid  {results[(d, 'hybrid')]}")

    # Lead time inside the crash window: onset = first extreme 1-minute move after a volatile 15 minutes
    w0, w1 = a.window.split(",")
    abs99 = feats.abs_ret_1.loc[tr_idx].quantile(0.999)
    rv995 = feats.rv_15.loc[tr_idx].quantile(0.995)
    fw = feats.loc[w0:w1]
    hit = fw[(fw.abs_ret_1 > abs99) & (fw.rv_15 > rv995)]
    lead = {}
    if len(hit):
        onset = hit.index[0]
        p = pwarn["instability"]
        eps = [e for e in _alarm_episodes(p) if e[0] <= onset <= e[1] + pd.Timedelta(minutes=1)]
        lead["event onset (UTC)"] = str(onset)
        lead["price at onset"] = f"{df.close[onset]:,.0f}"
        lead["price low in window"] = f"{df.low[w0:w1].min():,.0f} at {df.low[w0:w1].idxmin()}"
        if eps:
            lead["alarm switched on (UTC)"] = str(eps[0][0])
            lead["warning lead time"] = f"{int((onset - eps[0][0]).total_seconds() // 60)} minutes"
        else:
            lead["warning lead time"] = "no alarm before onset"
        first = p[w0:onset][p[w0:onset] >= 0.5]
        lead["first minute with P(Warning+) >= 0.5 in window"] = str(first.index[0]) if len(first) else "none"
    alarms = {}
    for d in te:
        p = pwarn["instability"][d]
        alarms[d] = len(_alarm_episodes(p))

    report.crash_chart(df, feats, levels.loc[te_idx], pred, pwarn, w0, w1, os.path.join(OUT, "crash_window.png"), "hybrid")
    report.prob_chart(pwarn, w0, w1, os.path.join(OUT, "escalation_probability.png"))
    report.importance_chart(imp, os.path.join(OUT, "feature_importance.png"))
    cfg = {"symbol": a.symbol, "train": tr, "test": te, "horizon": a.horizon}
    report.write_report(os.path.join(OUT, "report.md"), cfg, results, lead, alarms, imp, thr)

    out = feats.loc[te_idx].join(levels.loc[te_idx].add_prefix("actual_")).join(pred.add_prefix("pred_"))
    for d in DIMS:
        out[f"p_warn_{d}"] = pwarn[d]
    out.to_csv(os.path.join(OUT, "test_predictions.csv"))
    feats.join(levels.add_prefix("level_")).join(df.add_prefix("raw_")).to_csv(os.path.join(OUT, "dataset_minutes.csv"))
    joblib.dump({"models": {d: fitted[(d, "gboost")] for d in DIMS}, "horizon": a.horizon, "thresholds": thr,
                 "features": FEATURES, "symbol": a.symbol}, os.path.join(OUT, "detector.joblib"))
    json.dump({f"{d}|{m}": r for (d, m), r in results.items()} | {"lead": lead, "alarms": alarms},
              open(os.path.join(OUT, "metrics.json"), "w"), indent=2)
    print("Lead:", lead, "\nAlarms:", alarms, f"\nOutputs written to {os.path.abspath(OUT)}")


def cmd_score(a):
    bundle = joblib.load(os.path.join(OUT, "detector.joblib"))
    prev = (pd.Timestamp(a.day) - pd.Timedelta(days=1)).strftime("%Y-%m-%d")
    df = load_days(a.symbol, [prev, a.day])          # previous day warms up rolling windows
    nv = naive_levels(df, bundle.get("horizon", 15), bundle["thresholds"]).loc[a.day]
    feats = build_features(df).loc[a.day]
    rows = {}
    for d, m in bundle["models"].items():
        rows[f"level_{d}"] = np.maximum(m.predict(feats[bundle["features"]]), nv[d].values)
        rows[f"p_warn_{d}"] = np.maximum(prob_warning_plus(m, feats[bundle["features"]]), (nv[d].values >= 2).astype(float))
    res = pd.DataFrame(rows, index=feats.index)
    names = ["Normal", "Watch", "Warning", "Critical"]
    path = os.path.join(OUT, f"score_{a.symbol}_{a.day}.csv")
    res.to_csv(path)
    print(f"{a.day}: minutes at each predicted level")
    for d in bundle["models"]:
        vc = res[f"level_{d}"].map(dict(enumerate(names))).value_counts().reindex(names, fill_value=0)
        print(f"  {d:12s}", dict(vc))
    print(f"  instability alarm episodes: {len(_alarm_episodes(res['p_warn_instability']))}")
    print("Saved", os.path.abspath(path))


def main():
    ap = argparse.ArgumentParser(prog="crm")
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("train")
    t.add_argument("--symbol", default="BTCUSDT")
    t.add_argument("--train", default="2025-09-24:2025-10-09")
    t.add_argument("--test", default="2025-10-10:2025-10-13")
    t.add_argument("--horizon", type=int, default=15)
    t.add_argument("--window", default="2025-10-10 19:00,2025-10-11 01:00")
    s = sub.add_parser("score")
    s.add_argument("--symbol", default="BTCUSDT")
    s.add_argument("--day", required=True)
    a = ap.parse_args()
    cmd_train(a) if a.cmd == "train" else cmd_score(a)


if __name__ == "__main__":
    main()
