"""Group A features on 1-minute bars. Every feature uses only past and current data."""
import numpy as np
import pandas as pd

FEATURES = [
    # Binance aggTrades
    "ret_1", "abs_ret_1", "rv_15", "log_rv_15", "log_rv_60", "rv_ratio_15_60", "range_15",
    "log_vol_ratio_60", "ofi_1", "ofi_15", "persist_15", "persist_signed_15",
    # Bybit order book
    "spread_bps", "spread_ratio_60", "spread_max_15",
    "log_tob_depth", "log_near_depth", "near_depth_chg_15", "near_depth_ratio_60", "tob_imb",
]


def build_features(df):
    f = pd.DataFrame(index=df.index)
    lr = np.log(df.close).diff()
    f["ret_1"] = lr
    f["abs_ret_1"] = lr.abs()
    f["rv_15"] = lr.rolling(15).std()
    rv60 = lr.rolling(60).std()
    f["log_rv_15"] = np.log(f.rv_15 + 1e-6)
    f["log_rv_60"] = np.log(rv60 + 1e-6)
    f["rv_ratio_15_60"] = f.rv_15 / rv60                                   # volatility acceleration
    f["range_15"] = np.log(df.high.rolling(15).max() / df.low.rolling(15).min())
    f["log_vol_ratio_60"] = np.log1p(df.vol_usd) - np.log1p(df.vol_usd).rolling(60).median()
    f["ofi_1"] = df.signed_usd / df.vol_usd                                # buy/sell imbalance
    f["ofi_15"] = df.signed_usd.rolling(15).sum() / df.vol_usd.rolling(15).sum()
    sign = np.sign(f.ofi_1)
    f["persist_signed_15"] = sign.rolling(15).mean()                        # +1 all buys ... -1 all sells
    f["persist_15"] = f.persist_signed_15.abs()                            # same-direction persistence
    # Bybit book
    f["spread_bps"] = df.spread_bps_mean
    f["spread_ratio_60"] = np.log(df.spread_bps_mean / df.spread_bps_mean.rolling(60).median())
    f["spread_max_15"] = df.spread_bps_max.rolling(15).max()
    f["log_tob_depth"] = np.log(df.tob_depth_usd)
    f["log_near_depth"] = np.log(df.near_depth_usd)
    f["near_depth_chg_15"] = f.log_near_depth - f.log_near_depth.shift(15)  # depth decline speed
    f["near_depth_ratio_60"] = f.log_near_depth - f.log_near_depth.rolling(60).median()
    f["tob_imb"] = df.tob_imb
    return f.replace([np.inf, -np.inf], np.nan)
