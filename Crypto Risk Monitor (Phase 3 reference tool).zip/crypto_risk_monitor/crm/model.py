"""Per-dimension detectors: logistic regression benchmark vs gradient boosting."""
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, f1_score,
                             precision_score, recall_score)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from .labels import DIMS


def make_models():
    return {
        "logit": make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                               LogisticRegression(max_iter=3000, class_weight="balanced", C=0.5)),
        "gboost": HistGradientBoostingClassifier(max_iter=250, learning_rate=0.05, max_depth=4,
                                                 l2_regularization=1.0, class_weight="balanced",
                                                 random_state=0),
    }


def prob_warning_plus(model, X):
    p = model.predict_proba(X)
    cls = list(model.classes_)
    return sum(p[:, cls.index(c)] for c in (2, 3) if c in cls)


def evaluate(y, pred, p_warn):
    yb = (y >= 2).astype(int)
    out = {
        "macro_f1": f1_score(y, pred, average="macro", labels=[0, 1, 2, 3], zero_division=0),
        "critical_recall": recall_score(y == 3, pred == 3, zero_division=0),
        "critical_precision": precision_score(y == 3, pred == 3, zero_division=0),
        "warning_plus_pr_auc": average_precision_score(yb, p_warn) if yb.any() else np.nan,
        "warning_plus_base_rate": yb.mean(),
        "warning_plus_brier": brier_score_loss(yb, p_warn),
    }
    return {k: round(float(v), 4) for k, v in out.items()}


def train_all(Xtr, Ytr, Xte, Yte, features):
    results, preds, fitted, importance = {}, {}, {}, {}
    for d in DIMS:
        mtr, mte = Ytr[d] >= 0, Yte[d] >= 0
        for name, m in make_models().items():
            m.fit(Xtr.loc[mtr, features], Ytr.loc[mtr, d])
            pr = pd.Series(m.predict(Xte[features]), index=Xte.index)
            pw = pd.Series(prob_warning_plus(m, Xte[features]), index=Xte.index)
            results[(d, name)] = evaluate(Yte.loc[mte, d].values, pr[mte].values, pw[mte].values)
            preds[(d, name)] = (pr, pw)
            fitted[(d, name)] = m
        gb = fitted[(d, "gboost")]
        pi = permutation_importance(gb, Xte.loc[mte, features], Yte.loc[mte, d],
                                    scoring="f1_macro", n_repeats=5, random_state=0)
        importance[d] = pd.Series(pi.importances_mean, index=features).sort_values(ascending=False)
    return results, preds, fitted, importance
