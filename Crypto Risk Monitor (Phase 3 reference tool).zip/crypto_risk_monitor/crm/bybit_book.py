"""Rebuild the Bybit order book from daily snapshot + delta files and sample
top-of-book once per second."""
import zipfile
import numpy as np
import pandas as pd
try:
    import orjson as _json
    loads = _json.loads
except ImportError:  # fallback
    import json as _json
    loads = _json.loads

URL = "https://quote-saver.bycsi.com/orderbook/linear/{sym}/{day}_{sym}_ob{lvl}.data.zip"
NEAR_BPS = 10  # "near-touch" depth band: within 0.10% of mid


def parse_orderbook_zip(path):
    """Return a DataFrame indexed by second with best bid/ask, sizes and near-touch depth."""
    bids, asks = {}, {}
    rows = []
    cur_sec = None
    z = zipfile.ZipFile(path)
    with z.open(z.namelist()[0]) as f:
        for line in f:
            msg = loads(line)
            sec = msg["ts"] // 1000
            # record the book as it stood at the end of the previous second
            if cur_sec is not None and sec != cur_sec and bids and asks:
                rows.append(_top(cur_sec, bids, asks))
            cur_sec = sec
            d = msg["data"]
            if msg["type"] == "snapshot":
                bids = {float(p): float(q) for p, q in d["b"]}
                asks = {float(p): float(q) for p, q in d["a"]}
                continue
            for p, q in d["b"]:
                p, q = float(p), float(q)
                if q == 0.0:
                    bids.pop(p, None)
                else:
                    bids[p] = q
            for p, q in d["a"]:
                p, q = float(p), float(q)
                if q == 0.0:
                    asks.pop(p, None)
                else:
                    asks[p] = q
    if cur_sec is not None and bids and asks:
        rows.append(_top(cur_sec, bids, asks))
    df = pd.DataFrame(rows, columns=["sec", "bid", "ask", "bid_sz", "ask_sz", "bid_near", "ask_near"])
    df["ts"] = pd.to_datetime(df.pop("sec"), unit="s")
    return df.set_index("ts")


def _top(sec, bids, asks):
    bb, ba = max(bids), min(asks)
    mid = 0.5 * (bb + ba)
    lo, hi = mid * (1 - NEAR_BPS / 1e4), mid * (1 + NEAR_BPS / 1e4)
    bid_near = sum(p * q for p, q in bids.items() if p >= lo)
    ask_near = sum(p * q for p, q in asks.items() if p <= hi)
    return (sec, bb, ba, bids[bb], asks[ba], bid_near, ask_near)


def book_to_minutes(sec_df):
    """Aggregate 1-second top-of-book into 1-minute bars (all values in USD notional / bps)."""
    s = sec_df.copy()
    mid = 0.5 * (s.bid + s.ask)
    s["spread_bps"] = (s.ask - s.bid) / mid * 1e4
    s["tob_depth_usd"] = s.bid * s.bid_sz + s.ask * s.ask_sz
    s["near_depth_usd"] = s.bid_near + s.ask_near
    s["tob_imb"] = (s.bid_sz - s.ask_sz) / (s.bid_sz + s.ask_sz)
    s["mid"] = mid
    g = s.resample("1min")
    out = pd.DataFrame({
        "mid_bybit": g.mid.last(),
        "spread_bps_mean": g.spread_bps.mean(),
        "spread_bps_max": g.spread_bps.max(),
        "tob_depth_usd": g.tob_depth_usd.median(),
        "near_depth_usd": g.near_depth_usd.median(),
        "near_depth_min_usd": g.near_depth_usd.min(),
        "tob_imb": g.tob_imb.mean(),
        "book_secs": g.mid.count(),   # coverage check: seconds with a valid book
    })
    return out
